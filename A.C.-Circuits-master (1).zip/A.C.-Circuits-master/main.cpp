#include<iostream>
#include<math.h>
#include<string>
#include<complex>
#include <vector>
using namespace std;
#include "components.h"
#include "circuit.h"
#include "interface.h"
/* The circuit is represented by a tree structure */


int main(){
  interface();
  return 0;
}
